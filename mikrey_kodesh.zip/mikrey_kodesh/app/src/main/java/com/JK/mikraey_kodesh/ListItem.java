package com.JK.mikraey_kodesh;

import android.content.Context;

public class ListItem extends android.support.v7.widget.AppCompatTextView {

    public ListItem(Context context) {
        super(context);
    }



//    @Override
//    public void onClick(View view) {
//        if (view.getId() == R.id.delete_button)
//
//    }
}
