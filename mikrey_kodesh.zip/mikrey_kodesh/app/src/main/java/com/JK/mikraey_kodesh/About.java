package com.JK.mikraey_kodesh;

import android.content.ActivityNotFoundException;
import android.graphics.Color;
import android.graphics.Point;
import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.v4.content.ContextCompat;
import android.text.Spannable;
import android.text.method.LinkMovementMethod;
import android.view.Display;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class About extends Activity implements View.OnClickListener
{
	dataManage dm = new dataManage();
	ExpandableListView expandableListView;
	TextView linkToPurchase;
	TextView linkyakov;
	TextView linkrafi;
	TextView linkyoav;
	LinkMovementMethod linkMethod;
	ImageView topFrame, bottomFrame, textImage;
	RelativeLayout.LayoutParams params;
	ArrayList<String> a = new ArrayList<>(), b = new ArrayList<>(), c = new ArrayList<>();
	ArrayList<ArrayList<String>> qqq  = new ArrayList<>();
	ArrayList<ArrayList<ArrayList<String>>> www = new ArrayList<>();
	ExpandableListView.OnChildClickListener grandsonListener;

	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);


		setContentView(R.layout.activity_about);

		grandsonListener = new ExpandableListView.OnChildClickListener() {
			@Override
			public boolean onChildClick(ExpandableListView expandableListView, View view, int i, int i1, long l) {
				int bookId = (int) expandableListView.getTag();
				int chapter = 0;
				for(int j = i-1;j>-1;j--){
					chapter += dm.partsHeaders.get(j).size();
				}
				chapter+= i1;
				try
				{
					Class ourClass = Class.forName("com.JK.mikraey_kodesh.textMain");
					Intent ourIntent = new Intent(About.this, ourClass);
					int[] book_chapter = new int[2];
					book_chapter[0] = bookId;
					book_chapter[1] = chapter;
					ourIntent.putExtra("book_chapter", book_chapter);
					startActivity(ourIntent);
				}
				catch (ClassNotFoundException e)
				{
					e.printStackTrace();
				}

				return false;
			}
		};
		expandableListView = (ExpandableListView) findViewById(R.id.mainList);
		expandableListView.setAdapter(new ParentLevel(this, dm.mchaptersNames, dm.booksHeaders, dm.partsHeaders, grandsonListener));

		linkToPurchase = (TextView) findViewById(R.id.tvLinkToBuy);
		linkToPurchase.setMovementMethod(LinkMovementMethod.getInstance());
		linkToPurchase.setLinkTextColor(Color.BLUE);

		linkMethod = new LinkMovementMethod(){
			String emailAdress;
			@Override
			public boolean onTouchEvent(TextView widget, Spannable buffer, MotionEvent event) {
				switch (widget.getId()){
					case R.id.yakovLink:
						emailAdress = "yakov9k@gmail.com";
						break;
					case R.id.janLink:
						emailAdress = "rafraph@gmail.com";
						break;
					case R.id.yoavLink:
						emailAdress = "yoavsc4@gmail.com";
						break;
				}
				int action = event.getAction();
				if (action == MotionEvent.ACTION_UP){
					Intent emailIntent = new Intent (Intent.ACTION_SEND);
					emailIntent.setType("message/rfc822");
					emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{"to ", emailAdress});
					emailIntent.putExtra(Intent.EXTRA_SUBJECT, "");
					emailIntent.putExtra(Intent.EXTRA_TEXT, "");
					try {
						startActivity(Intent.createChooser(emailIntent, "בחר אפליקציית מייל"));
					} catch (ActivityNotFoundException e){
						Toast.makeText(About.this,"לא מותקנת אפליקציה לשליחת מייל?", Toast.LENGTH_SHORT).show();
					}
					return true;
				}
				return super.onTouchEvent(widget, buffer, event);
			}
		};

		linkyakov = (TextView) findViewById(R.id.yakovLink);
		linkrafi = (TextView) findViewById(R.id.janLink);
		linkyoav = (TextView) findViewById(R.id.yoavLink);

		linkyakov.setMovementMethod(linkMethod);
		linkrafi.setMovementMethod(linkMethod);
		linkyoav.setMovementMethod(linkMethod);

		linkyakov.setLinkTextColor(Color.BLACK);
		linkrafi.setLinkTextColor(Color.BLACK);
		linkyoav.setLinkTextColor(Color.BLACK);

		topFrame = findViewById(R.id.top_frame);
		bottomFrame = findViewById(R.id.bottom_frame);
		textImage = findViewById(R.id.about_text);

		textImage.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.text_about));
		topFrame.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.frame_about));
		bottomFrame.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.frame_about));

//		topFrame.getLayoutParams().height = (int) (topFrame.getLayoutParams().width/4.5);
//
//		bottomFrame.getLayoutParams().height = (int) (bottomFrame.getLayoutParams().width/4.5);
//
//		Display display = getWindowManager().getDefaultDisplay();
//		Point size = new Point();
//		display.getSize(size);
//		int height = (int) (size.x/4.5);
//		params = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height);
//		//params.height = (int) (topFrame.getLayoutParams().width/4.5);
//		topFrame.setLayoutParams(params);
//		bottomFrame.setLayoutParams(params);
//		bottomFrame.setBaselineAlignBottom(true);
//		topFrame.requestLayout();
//		bottomFrame.requestLayout();
		/*version*/
		String myVersionName = "not available"; // initialize String

		Context context = getApplicationContext(); // or activity.getApplicationContext()
		PackageManager packageManager = context.getPackageManager();
		String packageName = context.getPackageName();

		try 
		{
		    myVersionName = "גירסה: " + packageManager.getPackageInfo(packageName, 0).versionName;
		} 
		catch (PackageManager.NameNotFoundException e) 
		{
		    e.printStackTrace();
		}
		TextView tvVersion = (TextView) findViewById(R.id.textViewVersion);
		tvVersion.setText(myVersionName);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.about, menu);
		return true;
	}
	
	public void onClick(View v) 
	{
		// TODO Auto-generated method stub
	
		Intent intent = new Intent();
        intent.setAction(Intent.ACTION_VIEW);
        intent.addCategory(Intent.CATEGORY_BROWSABLE);
        intent.setData(Uri.parse("http://shop.yhb.org.il/"));
        startActivity(intent);
	}
}
